#!/bin/bash

# Configuration
MYSQL_ROOT_PASSWORD="CloudTVpass123"
DOMAIN="yourdomain.com"
EMAIL="admin@yourdomain.com"

FRONTEND_REPO="https://github.com/cloudtv/frontend"
BACKEND_REPO="https://github.com/cloudtv/backend"
INSTALL_DIR="/opt/cloudtv"
NODE_VERSION="18"

# Update system
apt update && apt upgrade -y

# Install dependencies
apt install -y curl git nginx mysql-server build-essential unzip ffmpeg software-properties-common

# MySQL root setup
mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$MYSQL_ROOT_PASSWORD'; FLUSH PRIVILEGES;"

# Node.js install
curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
apt install -y nodejs

# PM2 install
npm install -g pm2

# Clone and setup backend
mkdir -p $INSTALL_DIR
cd $INSTALL_DIR
git clone $BACKEND_REPO backend
cd backend
npm install
cp .env.example .env
sed -i "s/MYSQL_PASSWORD=.*/MYSQL_PASSWORD=$MYSQL_ROOT_PASSWORD/" .env
pm2 start index.js --name cloudtv-backend
pm2 save

# Clone and build frontend
cd $INSTALL_DIR
git clone $FRONTEND_REPO frontend
cd frontend
npm install
npm run build

# Configure Nginx
cat <<EOF > /etc/nginx/sites-available/cloudtv
server {
    listen 80;
    server_name $DOMAIN;

    root $INSTALL_DIR/frontend/build;
    index index.html;

    location / {
        try_files \$uri /index.html;
    }

    location /api/ {
        proxy_pass http://localhost:3000/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
    }
}
EOF

ln -s /etc/nginx/sites-available/cloudtv /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx

# SSL via Let's Encrypt
apt install -y certbot python3-certbot-nginx
certbot --nginx --non-interactive --agree-tos -m $EMAIL -d $DOMAIN

# PM2 auto-start
pm2 startup systemd
pm2 save

echo "✅ Installation Complete! Visit: https://$DOMAIN"
